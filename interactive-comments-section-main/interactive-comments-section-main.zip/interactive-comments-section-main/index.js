function openWin() {
  window.open("file:///C:/Users/d.m.mcmillan/OneDrive%20-%20Saint%20Kentigern/Y13/COM/HTML/interactive-comments-section-main/interactive-comments-section-main/coment.html");
}

function SendMessage() {
  
}